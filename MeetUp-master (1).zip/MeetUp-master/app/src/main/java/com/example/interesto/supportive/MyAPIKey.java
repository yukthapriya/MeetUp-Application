package com.example.interesto.supportive;

public class MyAPIKey {

    //first account
    final private static String myApikey="838f118f96444870bd7e8acd1e885f13";

    //second account
    //final private static String myApikey="b5a6aea1e7dd465e818dcc8454f10b40";

    //third account
    //final private static String myApikey="28986ebb55fc48dab785e9e75a1fde28";

    public static String getMyKey()
    {
        return myApikey;
    }
}
